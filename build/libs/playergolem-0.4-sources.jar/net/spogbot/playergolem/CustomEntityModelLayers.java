package net.spogbot.playergolem;

import net.minecraft.class_2960;
import net.minecraft.class_5601;

public class CustomEntityModelLayers {
    public static final class_5601 PLAYERGOLEM = new class_5601(
            class_2960.method_60655("playergolem", "playergolem"), "main"
    );

}