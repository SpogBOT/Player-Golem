package net.spogbot.playergolem;

import net.minecraft.class_11651;
import net.minecraft.class_11679;
import net.minecraft.class_4587;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

public class PlayergolemModel extends class_11651 {

    private final class_630 field_54014;
    private final class_630 body;
    private final class_630 head;
    private final class_630 leftArm;
    private final class_630 rightArm;
    private final class_630 leftLeg;
    private final class_630 rightLeg;

    public PlayergolemModel(class_630 root) {
        super(root);
        this.field_54014 = root;
        this.body = root.method_32086("body");
        this.head = body.method_32086("head");
        this.leftArm = body.method_32086("left_arm");
        this.rightArm = body.method_32086("right_arm");
        this.leftLeg = root.method_32086("left_leg");
        this.rightLeg = root.method_32086("right_leg");
    }

    public class_630 getRoot() {
        return this.field_54014;
    }

    // === GETTERS NEEDED FOR THE STATUE RENDERER ===
    public class_630 getBody()    { return body; }
    public class_630 method_2838()    { return head; }
    public class_630 getLeftArm() { return leftArm; }
    public class_630 getRightArm(){ return rightArm; }
    public class_630 getLeftLeg() { return leftLeg; }
    public class_630 getRightLeg(){ return rightLeg; }

    public static class_5607 method_72836() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();

        class_5610 body = modelPartData.method_32117("body", class_5606.method_32108()
                        .method_32101(16, 16).method_32098(-4.0F, -6.0F, -2.0F, 8.0F, 6.0F, 4.0F, new class_5605(0.0F))
                        .method_32101(16, 32).method_32098(-4.0F, -6.0F, -2.0F, 8.0F, 6.0F, 4.0F, new class_5605(0.25F)),
                class_5603.method_32090(0.0F, 19.0F, 0.0F));

        body.method_32117("head", class_5606.method_32108()
                        .method_32101(0, 0).method_32098(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new class_5605(0.0F))
                        .method_32101(32, 0).method_32098(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new class_5605(0.5F))
                        .method_32101(24, 0).method_32098(-1.0F, -5.0F, -3.0F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F))
                        .method_32101(11, 0).method_32098(-1.0F, -7.9F, -1.0F, 2.0F, 4.0F, 2.0F, new class_5605(-0.01F))
                        .method_32101(8, 0).method_32098(-2.0F, -7.9F, -2.0F, 4.0F, 4.0F, 4.0F, new class_5605(-0.01F)),
                class_5603.method_32090(0.0F, -6.0F, 0.0F));

        body.method_32117("left_arm", class_5606.method_32108()
                        .method_32101(32, 48).method_32098(0.0F, -1.0F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F))
                        .method_32101(48, 48).method_32098(0.0F, -1.0F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.25F)),
                class_5603.method_32090(4.0F, -6.0F, 0.0F));

        body.method_32117("right_arm", class_5606.method_32108()
                        .method_32101(40, 16).method_32098(-3.0F, -1.0F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F))
                        .method_32101(40, 32).method_32098(-3.0F, -1.0F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.25F)),
                class_5603.method_32090(-4.0F, -6.0F, 0.0F));

        modelPartData.method_32117("left_leg", class_5606.method_32108()
                        .method_32101(16, 48).method_32098(-0.1F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F))
                        .method_32101(0, 48).method_32098(-0.1F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.25F)),
                class_5603.method_32090(0.0F, 19.0F, 0.0F));

        modelPartData.method_32117("right_leg", class_5606.method_32108()
                        .method_32101(0, 16).method_32098(-3.9F, 0.0F, -1.99F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F))
                        .method_32101(0, 32).method_32098(-3.9F, 0.0F, -1.99F, 4.0F, 5.0F, 4.0F, new class_5605(0.25F)),
                class_5603.method_32090(0.0F, 19.0F, 0.0F));

        return class_5607.method_32110(modelData, 64, 64);
    }

    @Override
    public void method_72839(class_11679 state) {
        super.method_72839(state);
    }

    @Override
    public void method_73223(class_4587 matrices) {
        super.method_73223(matrices);
        matrices.method_22904(0.0D, 4.0D / 16.0D, 0.0D);
    }
}