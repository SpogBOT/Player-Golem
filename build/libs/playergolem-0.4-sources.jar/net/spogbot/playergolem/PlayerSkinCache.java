package net.spogbot.playergolem;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Base64;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class PlayerSkinCache {
    // Изменили тип значения в кэше на Optional<Identifier>
    private static final ConcurrentHashMap<String, CompletableFuture<Optional<class_2960>>> CACHE = new ConcurrentHashMap<>();
    private static final HttpClient HTTP_CLIENT = HttpClient.newHttpClient();

    public static CompletableFuture<Optional<class_2960>> getOrLoad(String name) {
        if (name == null || name.trim().isEmpty()) {
            return CompletableFuture.completedFuture(Optional.empty()); // Если ника нет — возвращаем пустоту
        }
        String key = name.trim().toLowerCase();
        return CACHE.computeIfAbsent(key, PlayerSkinCache::loadSkinAsync);
    }

    private static CompletableFuture<Optional<class_2960>> loadSkinAsync(String name) {
        return fetchSkinUrl(name)
                .thenCompose(urlOpt -> urlOpt.isPresent()
                        ? downloadAndRegisterTexture(name, urlOpt.get())
                        : CompletableFuture.completedFuture(Optional.<class_2960>empty()))
                .exceptionally(e -> {
                    return Optional.empty();
                });
    }

    private static CompletableFuture<Optional<String>> fetchSkinUrl(String name) {
        return fetchUuid(name).thenCompose(uuidOpt -> {
            if (uuidOpt.isEmpty()) return CompletableFuture.completedFuture(Optional.empty());
            String uuidStr = uuidOpt.get().toString().replace("-", "");

            return CompletableFuture.supplyAsync(() -> {
                try {
                    String url = "https://sessionserver.mojang.com/session/minecraft/profile/" + uuidStr;
                    HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                            .timeout(Duration.ofSeconds(10))
                            .GET()
                            .build();

                    HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                    if (response.statusCode() != 200) return Optional.empty();

                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    JsonArray properties = json.getAsJsonArray("properties");

                    for (var elem : properties) {
                        JsonObject prop = elem.getAsJsonObject();
                        if ("textures".equals(prop.get("name").getAsString())) {
                            String base64 = prop.get("value").getAsString();
                            String decoded = new String(Base64.getDecoder().decode(base64));
                            JsonObject texturesJson = JsonParser.parseString(decoded).getAsJsonObject()
                                    .getAsJsonObject("textures");

                            String skinUrl = texturesJson.getAsJsonObject("SKIN").get("url").getAsString();
                            return Optional.of(skinUrl);
                        }
                    }
                } catch (Exception ignored) {}
                return Optional.empty();
            }, class_156.method_18349());
        });
    }

    private static CompletableFuture<Optional<java.util.UUID>> fetchUuid(String name) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create("https://api.mojang.com/users/profiles/minecraft/" + name))
                        .timeout(Duration.ofSeconds(8))
                        .GET()
                        .build();

                HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() == 200) {
                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    String id = json.get("id").getAsString();
                    java.util.UUID uuid = new java.util.UUID(
                            Long.parseUnsignedLong(id.substring(0, 16), 16),
                            Long.parseUnsignedLong(id.substring(16), 16)
                    );
                    return Optional.of(uuid);
                }
            } catch (Exception ignored) {}
            return Optional.empty();
        }, class_156.method_18349());
    }

    private static CompletableFuture<Optional<class_2960>> downloadAndRegisterTexture(String name, String skinUrl) {
        class_2960 textureId = class_2960.method_60655("copperfriends", "skins/" + name.toLowerCase().replaceAll("[^a-z0-9/._-]", "_"));

        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(skinUrl))
                        .timeout(Duration.ofSeconds(15))
                        .GET()
                        .build();

                HttpResponse<byte[]> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofByteArray());
                if (response.statusCode() != 200) {
                    return Optional.<class_2960>empty();
                }

                class_1011 image = class_1011.method_49277(response.body());
                CompletableFuture<Optional<class_2960>> registerFuture = new CompletableFuture<>();

                class_310.method_1551().execute(() -> {
                    try {
                        class_1043 texture = new class_1043(() -> textureId.toString(), image);
                        class_310.method_1551().method_1531().method_4616(textureId, texture);
                        registerFuture.complete(Optional.of(textureId));
                    } catch (Exception e) {
                        e.printStackTrace();
                        registerFuture.complete(Optional.empty());
                    }
                });

                return registerFuture.join();
            } catch (Exception e) {
                e.printStackTrace();
                return Optional.empty();
            }
        }, class_156.method_18349());
    }

    public static void clearCache() {
        CACHE.clear();
    }

    public static void invalidate(String playerName) {
        if (playerName == null || playerName.trim().isEmpty()) {
            CACHE.clear();
        } else {
            String key = playerName.trim().toLowerCase();
            if (CACHE.remove(key) != null) {
            } else {
            }
        }
    }
}