package net.spogbot.playergolem;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_11573;
import net.minecraft.class_11659;
import net.minecraft.class_11678;
import net.minecraft.class_11679;
import net.minecraft.class_11745;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import net.minecraft.class_989;

public class PlayergolemRenderer extends class_927<class_11573, PlayergolemRenderer.PlayergolemRenderState, PlayergolemModel> {

    private final class_11678 vanillaRenderer;

    public PlayergolemRenderer(class_5617.class_5618 context) {
        super(context, new PlayergolemModel(context.method_32167(CustomEntityModelLayers.PLAYERGOLEM)), 0.5f);
        this.vanillaRenderer = new class_11678(context);

        this.method_4046(new class_11745(
                this,
                state -> ((class_11679) state).field_62049,
                (Object obj) -> ((PlayergolemModel) this.field_4737).method_73223((class_4587) obj)
        ));

        this.method_4046(new class_989(this));
    }

    @Override
    public PlayergolemRenderState method_55269() {
        return new PlayergolemRenderState();
    }

    @Override
    public void updateRenderState(class_11573 entity, PlayergolemRenderState state, float tickDelta) {
        this.vanillaRenderer.method_72965(entity, state, tickDelta);

        if (entity.method_16914()) {
            String playerName = entity.method_5797().getString().trim();
            if (state.lastPlayerName == null || !state.lastPlayerName.equals(playerName)) {
                state.lastPlayerName = playerName;
                state.skinFuture = PlayerSkinCache.getOrLoad(playerName);
                state.resolvedSkin = Optional.empty();
            }
            if (state.resolvedSkin.isEmpty() && state.skinFuture != null && state.skinFuture.isDone()) {
                state.resolvedSkin = state.skinFuture.join();
            }
        } else {
            state.lastPlayerName = null;
            state.skinFuture = null;
            state.resolvedSkin = Optional.empty();
        }

        state.useCustomModel = state.resolvedSkin.isPresent();
    }

    @Override
    protected class_1921 getRenderLayer(PlayergolemRenderState state, boolean showBody, boolean translucent, boolean showOutline) {
        if (state.useCustomModel) {
            return class_12249.method_76000(getTexture(state));
        }
        return super.method_24302(state, showBody, translucent, showOutline);
    }

    @Override
    public void render(PlayergolemRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState) {
        if (!state.useCustomModel) {
            this.vanillaRenderer.method_4054(state, matrices, queue, cameraRenderState);
            return;
        }
        super.method_4054(state, matrices, queue, cameraRenderState);
    }

    @Override
    public class_2960 getTexture(PlayergolemRenderState state) {
        return state.resolvedSkin.orElse(class_2960.method_60655("minecraft", "textures/entity/copper_golem/copper_golem.png"));
    }

    public static class PlayergolemRenderState extends class_11679 {
        public String lastPlayerName = null;
        public CompletableFuture<Optional<class_2960>> skinFuture = null;
        public Optional<class_2960> resolvedSkin = Optional.empty();
        public boolean useCustomModel = false;
    }
}